namespace Assignment2_17272381.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class InitialDatabase : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.ParkingSpaces",
                c => new
                    {
                        ID = c.Int(nullable: false, identity: true),
                        Location_AddressLine1 = c.String(nullable: false),
                        Location_AddressLine2 = c.String(nullable: false),
                        Location_Town = c.String(nullable: false),
                        Location_Country = c.String(nullable: false),
                        NumberOfParks = c.Int(nullable: false),
                        Price = c.Decimal(nullable: false, precision: 18, scale: 2),
                        ListingDate = c.DateTime(nullable: false),
                        AvailableDate = c.DateTime(nullable: false),
                        Description = c.String(),
                        ZoneID = c.Int(),
                    })
                .PrimaryKey(t => t.ID)
                .ForeignKey("dbo.Zones", t => t.ZoneID)
                .Index(t => t.ZoneID);
            
            CreateTable(
                "dbo.Zones",
                c => new
                    {
                        ID = c.Int(nullable: false, identity: true),
                        Suburb = c.String(),
                        City = c.String(),
                        Country = c.String(),
                    })
                .PrimaryKey(t => t.ID);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.ParkingSpaces", "ZoneID", "dbo.Zones");
            DropIndex("dbo.ParkingSpaces", new[] { "ZoneID" });
            DropTable("dbo.Zones");
            DropTable("dbo.ParkingSpaces");
        }
    }
}
