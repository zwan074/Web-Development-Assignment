namespace Assignment2_17272381.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class ParkingSpaceImages : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.ParkingSpaceImages",
                c => new
                    {
                        ID = c.Int(nullable: false, identity: true),
                        FileName = c.String(),
                    })
                .PrimaryKey(t => t.ID);
            
        }
        
        public override void Down()
        {
            DropTable("dbo.ParkingSpaceImages");
        }
    }
}
