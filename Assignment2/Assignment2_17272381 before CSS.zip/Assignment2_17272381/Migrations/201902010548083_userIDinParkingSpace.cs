namespace Assignment2_17272381.Migrations.StoreConfiguration
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class userIDinParkingSpace : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.ParkingSpaces", "UserID", c => c.String());
        }
        
        public override void Down()
        {
            DropColumn("dbo.ParkingSpaces", "UserID");
        }
    }
}
