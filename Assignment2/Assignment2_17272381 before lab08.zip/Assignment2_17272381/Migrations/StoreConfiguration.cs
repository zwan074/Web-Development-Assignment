
using Assignment2_17272381.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity.Migrations;
using System.Linq;

namespace Assignment2_17272381.Migrations.StoreConfiguration
{

    internal sealed class StoreConfiguration : DbMigrationsConfiguration<Assignment2_17272381.OSDB.StoreContext>
    {
        public StoreConfiguration()
        {
            AutomaticMigrationsEnabled = false;
        }

        protected override void Seed(Assignment2_17272381.OSDB.StoreContext context)
        {
            var zones = new List<Zone>
            {
                new Zone {Suburb = "Avondale" , City = "Auckland" , Country = "New Zealand" },
                new Zone {Suburb = "Botany" , City = "Auckland" , Country = "New Zealand" },
                new Zone {Suburb = "Epsom" , City = "Auckland" , Country = "New Zealand"  },
                new Zone {Suburb = "Mount Eden" , City = "Auckland" , Country = "New Zealand"  },
                new Zone {Suburb = "Mount Albert" , City = "Auckland" , Country = "New Zealand" },
                new Zone {Suburb = "New Lynn" , City = "Auckland" , Country = "New Zealand"  },

             };
            zones.ForEach(c => context.Zones.AddOrUpdate(p => p.Suburb, c));
            context.SaveChanges();

            var parkingSpaces = new List<ParkingSpace>
            {


                new ParkingSpace {Location = new Location {AddressLine1 = "2 Hendon Ave", AddressLine2 = "Mount Albert" , Town = " Auckland", Country = "New Zealand"} ,
                    NumberOfParks = 1, Price = 631,ListingDate = DateTime.Parse("1-9-2018"),
                    Description = "easy access",
                    AvailableDate = DateTime.Parse("1-10-2018"),
                    ZoneID = zones.Single(c=>c.Suburb == "Mount Albert").ID},

                 new ParkingSpace {Location = new Location {AddressLine1 = "4 Hendon Ave", AddressLine2 = "Mount Albert" , Town = " Auckland", Country = "New Zealand"} ,
                    NumberOfParks = 1, Price = 700,ListingDate = DateTime.Parse("1-9-2018"),
                    Description = "difficult access",
                    AvailableDate =DateTime.Parse("1-11-2018"),
                    ZoneID = zones.Single(c=>c.Suburb == "Mount Albert").ID},

                  new ParkingSpace {Location = new Location {AddressLine1 = "8 Marshall Ave", AddressLine2 = "Epsom" , Town = " Auckland", Country = "New Zealand"} ,
                    NumberOfParks = 5, Price = 1000,ListingDate = DateTime.Parse("30-12-2011") ,
                    Description = "easy access",
                    AvailableDate = DateTime.Parse("1-12-2012") ,
                    ZoneID = zones.Single(c=>c.Suburb == "Epsom").ID},

                   new ParkingSpace {Location = new Location {AddressLine1 = "20 Marshall Ave", AddressLine2 = "Epsom" , Town = " Auckland", Country = "New Zealand"} ,
                    NumberOfParks = 2, Price = 1500,ListingDate = DateTime.Parse("30-12-2011") ,
                    Description = "easy access",
                    AvailableDate = DateTime.Parse("1-12-2012") ,
                    ZoneID = zones.Single(c=>c.Suburb == "Epsom").ID},

            };
            parkingSpaces.ForEach(c => context.ParkingSpaces.AddOrUpdate(p => p.Zone, c));
            context.SaveChanges();

        }

    }
}
