namespace Assignment2_17272381.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class ZoneNameValidation : DbMigration
    {
        public override void Up()
        {
            AlterColumn("dbo.ParkingSpaces", "Description", c => c.String(nullable: false, maxLength: 200));
            AlterColumn("dbo.Zones", "Suburb", c => c.String(nullable: false, maxLength: 50));
            AlterColumn("dbo.Zones", "City", c => c.String(nullable: false, maxLength: 50));
            AlterColumn("dbo.Zones", "Country", c => c.String(nullable: false, maxLength: 50));
        }
        
        public override void Down()
        {
            AlterColumn("dbo.Zones", "Country", c => c.String());
            AlterColumn("dbo.Zones", "City", c => c.String());
            AlterColumn("dbo.Zones", "Suburb", c => c.String());
            AlterColumn("dbo.ParkingSpaces", "Description", c => c.String());
        }
    }
}
