namespace Assignment2_17272381.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class CreateParkingSpaceImageMappings : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.ParkingSpaceImageMappings",
                c => new
                    {
                        ID = c.Int(nullable: false, identity: true),
                        ImageNumber = c.Int(nullable: false),
                        ParkingSpaceID = c.Int(nullable: false),
                        ParkingSpaceImageID = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.ID)
                .ForeignKey("dbo.ParkingSpaces", t => t.ParkingSpaceID, cascadeDelete: true)
                .ForeignKey("dbo.ParkingSpaceImages", t => t.ParkingSpaceImageID, cascadeDelete: true)
                .Index(t => t.ParkingSpaceID)
                .Index(t => t.ParkingSpaceImageID);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.ParkingSpaceImageMappings", "ParkingSpaceImageID", "dbo.ParkingSpaceImages");
            DropForeignKey("dbo.ParkingSpaceImageMappings", "ParkingSpaceID", "dbo.ParkingSpaces");
            DropIndex("dbo.ParkingSpaceImageMappings", new[] { "ParkingSpaceImageID" });
            DropIndex("dbo.ParkingSpaceImageMappings", new[] { "ParkingSpaceID" });
            DropTable("dbo.ParkingSpaceImageMappings");
        }
    }
}
