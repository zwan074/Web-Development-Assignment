﻿namespace Assignment2_17272381.Models
{
    public class ParkingSpaceImageMapping
    {

        public int ID { get; set; }
        public int ImageNumber { get; set; }
        public int ParkingSpaceID { get; set; }
        public int ParkingSpaceImageID { get; set; }
        public virtual ParkingSpace ParkingSpace { get; set; }
        public virtual ParkingSpaceImage ParkingSpaceImage { get; set; }

    }
}