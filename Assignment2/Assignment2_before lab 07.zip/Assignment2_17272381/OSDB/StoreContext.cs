﻿using Assignment2_17272381.Models;
using System.Data.Entity;

namespace Assignment2_17272381.OSDB
{
    public class StoreContext : DbContext
    {
        public DbSet<ParkingSpace> ParkingSpaces { get; set; }
        public DbSet<Zone> Zones { get; set; }
        public DbSet<ParkingSpaceImage> ParkingSpaceImages { get; set; }
        public DbSet<ParkingSpaceImageMapping> ParkingSpaceImageMappings { get; set; }
    }
}
