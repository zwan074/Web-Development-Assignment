namespace Assignment2_17272381.Migrations.StoreConfiguration
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class AddBasketLine : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.BasketLines",
                c => new
                    {
                        ID = c.Int(nullable: false, identity: true),
                        BasketID = c.String(),
                        ParkingSpaceID = c.Int(nullable: false),
                        Quantity = c.Int(nullable: false),
                        DateCreated = c.DateTime(nullable: false),
                    })
                .PrimaryKey(t => t.ID)
                .ForeignKey("dbo.ParkingSpaces", t => t.ParkingSpaceID, cascadeDelete: true)
                .Index(t => t.ParkingSpaceID);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.BasketLines", "ParkingSpaceID", "dbo.ParkingSpaces");
            DropIndex("dbo.BasketLines", new[] { "ParkingSpaceID" });
            DropTable("dbo.BasketLines");
        }
    }
}
