
using Assignment2_17272381.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity.Migrations;
using System.Linq;

namespace Assignment2_17272381.Migrations.StoreConfiguration
{

    internal sealed class StoreConfiguration : DbMigrationsConfiguration<Assignment2_17272381.OSDB.StoreContext>
    {
        public StoreConfiguration()
        {
            AutomaticMigrationsEnabled = false;
        }

        protected override void Seed(Assignment2_17272381.OSDB.StoreContext context)
        {
            var zones = new List<Zone>
            {
                new Zone {Suburb = "Avondale" , City = "Auckland" , Country = "New Zealand" },
                new Zone {Suburb = "Botany" , City = "Auckland" , Country = "New Zealand" },
                new Zone {Suburb = "Epsom" , City = "Auckland" , Country = "New Zealand"  },
                new Zone {Suburb = "Mount Eden" , City = "Auckland" , Country = "New Zealand"  },
                new Zone {Suburb = "Mount Albert" , City = "Auckland" , Country = "New Zealand" },
                new Zone {Suburb = "New Lynn" , City = "Auckland" , Country = "New Zealand"  },

             };
            zones.ForEach(c => context.Zones.AddOrUpdate(p => p.Suburb, c));
            context.SaveChanges();

            var parkingSpaces = new List<ParkingSpace>
            {


                new ParkingSpace {Location = new Location {AddressLine1 = "2 Hendon Ave", AddressLine2 = "Mount Albert" , Town = " Auckland", Country = "New Zealand"} ,
                    NumberOfParks = 1, Price = 631,ListingDate = DateTime.Parse("1-9-2018"),
                    Description = "easy access",
                    AvailableDate = DateTime.Parse("1-10-2018"),
                    ZoneID = zones.Single(c=>c.Suburb == "Mount Albert").ID,
                    UserID = "admin1@OnlineStore.com"},

                 new ParkingSpace {Location = new Location {AddressLine1 = "4 Hendon Ave", AddressLine2 = "Botany" , Town = " Auckland", Country = "New Zealand"} ,
                    NumberOfParks = 1, Price = 700,ListingDate = DateTime.Parse("1-9-2018"),
                    Description = "difficult access",
                    AvailableDate =DateTime.Parse("1-11-2018"),
                    ZoneID = zones.Single(c=>c.Suburb == "Mount Albert").ID,
                    UserID = "user1@onlinestore.com"},

                  new ParkingSpace {Location = new Location {AddressLine1 = "8 Marshall Ave", AddressLine2 = "New Lynn" , Town = " Auckland", Country = "New Zealand"} ,
                    NumberOfParks = 5, Price = 1000,ListingDate = DateTime.Parse("30-12-2011") ,
                    Description = "15min to CBD",
                    AvailableDate = DateTime.Parse("1-12-2012") ,
                    ZoneID = zones.Single(c=>c.Suburb == "Epsom").ID,
                    UserID = "user1@onlinestore.com"},

                   new ParkingSpace {Location = new Location {AddressLine1 = "20 Marshall Ave", AddressLine2 = "Epsom" , Town = " Auckland", Country = "New Zealand"} ,
                    NumberOfParks = 2, Price = 1500,ListingDate = DateTime.Parse("30-12-2011") ,
                    Description = "easy access",
                    AvailableDate = DateTime.Parse("1-12-2012") ,
                    ZoneID = zones.Single(c=>c.Suburb == "Epsom").ID,
                    UserID = "user2@onlinestore.com"},

            };

            parkingSpaces.ForEach(c => context.ParkingSpaces.AddOrUpdate(p => p.Zone, c));
            context.SaveChanges();

            var orders = new List<Order>
            {

                new Order { DeliveryAddress = new Address { AddressLine1="1 Some Street", Town="Town1",
                 AddressLine2="2 Some Street", Country="Country", PostCode="PostCode" }, TotalPrice=631,
                 UserID="admin@example.com", DateCreated=new DateTime(2014, 1, 1) ,
                 DeliveryName="Admin" },
                new Order { DeliveryAddress = new Address { AddressLine1="1 Some Street", Town="Town1",
                 AddressLine2="2 Some Street", Country="Country", PostCode="PostCode" }, TotalPrice=239,
                 UserID="admin@example.com", DateCreated=new DateTime(2014, 1, 2) ,
                 DeliveryName="Admin" },
                new Order { DeliveryAddress = new Address { AddressLine1="1 Some Street", Town="Town1",
                 AddressLine2="2 Some Street", Country="Country", PostCode="PostCode" }, TotalPrice=239,
                 UserID="admin@example.com", DateCreated=new DateTime(2014, 1, 3) ,
                 DeliveryName="Admin" },
                new Order { DeliveryAddress = new Address { AddressLine1="1 Some Street", Town="Town1",
                 AddressLine2="2 Some Street", Country="County", PostCode="PostCode" }, TotalPrice=631,
                 UserID="admin@example.com", DateCreated=new DateTime(2014, 1, 4) ,
                 DeliveryName="Admin" },
                new Order { DeliveryAddress = new Address { AddressLine1="1 Some Street", Town="Town1",
                 AddressLine2="2 Some Street", Country="Country", PostCode="PostCode" }, TotalPrice=19.49M,
                 UserID="admin@example.com", DateCreated=new DateTime(2014, 1, 5) ,
                 DeliveryName="Admin" }
            };

            orders.ForEach(c => context.Orders.AddOrUpdate(o => o.DateCreated, c));
            context.SaveChanges();

            var orderLines = new List<OrderLine>
            {
                new OrderLine { OrderID = 5, ParkingSpaceID = parkingSpaces.Single( c=> c.Location.AddressLine1 == "2 Hendon Ave").ID,
                    Location ="2 Hendon Ave", Quantity =1, UnitPrice=parkingSpaces.Single( c=> c.Location.AddressLine1 == "2 Hendon Ave").Price },

                new OrderLine { OrderID = 6, ParkingSpaceID = parkingSpaces.Single( c=> c.Location.AddressLine1 == "4 Hendon Ave").ID,
                 Location="4 Hendon Ave", Quantity=1, UnitPrice=parkingSpaces.Single( c=> c.Location.AddressLine1 =="4 Hendon Ave").Price },

                new OrderLine { OrderID = 7, ParkingSpaceID = parkingSpaces.Single( c=> c.Location.AddressLine1 == "8 Marshall Ave").ID,
                    Location ="4 Hendon Ave", Quantity=1, UnitPrice=parkingSpaces.Single( c=> c.Location.AddressLine1 == "8 Marshall Ave").Price },

                new OrderLine { OrderID = 8, ParkingSpaceID = parkingSpaces.Single( c=> c.Location.AddressLine1== "8 Marshall Ave").ID,
                    Location ="8 Marshall Ave", Quantity=1, UnitPrice=parkingSpaces.Single( c=> c.Location.AddressLine1 == "8 Marshall Ave").Price },

                new OrderLine { OrderID = 9, ParkingSpaceID = parkingSpaces.Single( c=> c.Location.AddressLine1 == "8 Marshall Ave").ID,
                    Location ="8 Marshall Ave", Quantity=1, UnitPrice=parkingSpaces.Single( c=> c.Location.AddressLine1== "8 Marshall Ave").Price }
            };

            orderLines.ForEach(c => context.OrderLines.AddOrUpdate(ol => ol.OrderID, c));
            context.SaveChanges();


        }

    }
}
