namespace Assignment2_17272381.Migrations.StoreConfiguration
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class twocontextreset : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.ParkingSpaceImageMappings",
                c => new
                    {
                        ID = c.Int(nullable: false, identity: true),
                        ImageNumber = c.Int(nullable: false),
                        ParkingSpaceID = c.Int(nullable: false),
                        ParkingSpaceImageID = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.ID)
                .ForeignKey("dbo.ParkingSpaces", t => t.ParkingSpaceID, cascadeDelete: true)
                .ForeignKey("dbo.ParkingSpaceImages", t => t.ParkingSpaceImageID, cascadeDelete: true)
                .Index(t => t.ParkingSpaceID)
                .Index(t => t.ParkingSpaceImageID);
            
            CreateTable(
                "dbo.ParkingSpaces",
                c => new
                    {
                        ID = c.Int(nullable: false, identity: true),
                        Location_AddressLine1 = c.String(nullable: false),
                        Location_AddressLine2 = c.String(nullable: false),
                        Location_Town = c.String(nullable: false),
                        Location_Country = c.String(nullable: false),
                        NumberOfParks = c.Int(nullable: false),
                        Price = c.Decimal(nullable: false, precision: 18, scale: 2),
                        ListingDate = c.DateTime(nullable: false),
                        AvailableDate = c.DateTime(nullable: false),
                        Description = c.String(nullable: false, maxLength: 200),
                        ZoneID = c.Int(),
                    })
                .PrimaryKey(t => t.ID)
                .ForeignKey("dbo.Zones", t => t.ZoneID)
                .Index(t => t.ZoneID);
            
            CreateTable(
                "dbo.Zones",
                c => new
                    {
                        ID = c.Int(nullable: false, identity: true),
                        Suburb = c.String(nullable: false, maxLength: 50),
                        City = c.String(nullable: false, maxLength: 50),
                        Country = c.String(nullable: false, maxLength: 50),
                    })
                .PrimaryKey(t => t.ID);
            
            CreateTable(
                "dbo.ParkingSpaceImages",
                c => new
                    {
                        ID = c.Int(nullable: false, identity: true),
                        FileName = c.String(maxLength: 100),
                    })
                .PrimaryKey(t => t.ID)
                .Index(t => t.FileName, unique: true);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.ParkingSpaceImageMappings", "ParkingSpaceImageID", "dbo.ParkingSpaceImages");
            DropForeignKey("dbo.ParkingSpaces", "ZoneID", "dbo.Zones");
            DropForeignKey("dbo.ParkingSpaceImageMappings", "ParkingSpaceID", "dbo.ParkingSpaces");
            DropIndex("dbo.ParkingSpaceImages", new[] { "FileName" });
            DropIndex("dbo.ParkingSpaces", new[] { "ZoneID" });
            DropIndex("dbo.ParkingSpaceImageMappings", new[] { "ParkingSpaceImageID" });
            DropIndex("dbo.ParkingSpaceImageMappings", new[] { "ParkingSpaceID" });
            DropTable("dbo.ParkingSpaceImages");
            DropTable("dbo.Zones");
            DropTable("dbo.ParkingSpaces");
            DropTable("dbo.ParkingSpaceImageMappings");
        }
    }
}
