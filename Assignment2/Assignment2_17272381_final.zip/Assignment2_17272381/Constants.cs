﻿namespace Assignment2_17272381
{
    public class Constants
    {
        public const string ParkingSpaceImagePath = "~/Content/ParkingSpaceImages/";
        public const string ParkingSpaceThumbnailPath = "~/Content/ParkingSpaceImages/Thumbnails/";
        public const int PagedItems = 3;
        public const int NumberOfParkingSpaceImages = 5;
    }
}