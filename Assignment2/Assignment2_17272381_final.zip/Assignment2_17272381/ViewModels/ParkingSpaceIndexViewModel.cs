﻿using Assignment2_17272381.Models;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using PagedList;

namespace Assignment2_17272381.ViewModels
{
    public class ParkingSpaceIndexViewModel
    {
        public IPagedList<ParkingSpace> ParkingSpaces { get; set; }
        //public IQueryable<ParkingSpace> ParkingSpaces { get; set; }
        public string Search { get; set; }
        public IEnumerable<ZoneWithCount> ZonesWithCount { get; set; }
        public string Zone { get; set; }
        public string SortBy { get; set; }
        public Dictionary<string, string> Sorts { get; set; }

        public IEnumerable<SelectListItem> ZoneFilterItems
        {
            get
            {
                var allZones = ZonesWithCount.Select(cc => new SelectListItem
                {
                    Value = cc.ZoneName,
                    Text = cc.ZoneNameWithCount
                });
                return allZones;
            }
        }
    }

    public class ZoneWithCount
    {
        public int ParkingSpaceCount { get; set; }
        public string ZoneName { get; set; }
        public string ZoneNameWithCount
        {
            get
            {
                return ZoneName + " (" + ParkingSpaceCount.ToString() + ")";
            }
        }
    }
}
